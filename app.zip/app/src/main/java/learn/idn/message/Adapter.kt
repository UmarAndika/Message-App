package learn.idn.message

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView

class Adapter (private val newList: ArrayList<Messages>) : RecyclerView.Adapter<Adapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.model,
        parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = newList[position]
        holder.bindImager.setImageResource(currentItem.titleImage)
        holder.bindSender.text = currentItem.heading
    }

    override fun getItemCount(): Int {
        return newList.size
    }

    class ViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
        val bindImager: ShapeableImageView = itemView.findViewById(R.id.images)
        val bindSender: TextView = itemView.findViewById(R.id.name)
        val bindMessager: TextView = itemView.findViewById(R.id.message)
        val bindDater: TextView = itemView.findViewById(R.id.date)
    }

}