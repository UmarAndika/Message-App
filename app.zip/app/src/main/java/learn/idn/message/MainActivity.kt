package learn.idn.message

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import learn.idn.message.R.drawable.ic_person

class MainActivity : AppCompatActivity() {

    private lateinit var newRecyclerView : RecyclerView
    private lateinit var newArrayList : ArrayList<Messages>
    lateinit var imageId : ArrayList<Int>
    lateinit var sender : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sender = arrayOf(
            "Umar",
            "Andika"
        )

        newRecyclerView = findViewById(R.id.model_rv)
        newRecyclerView.layoutManager = LinearLayoutManager(this)
        newRecyclerView.setHasFixedSize(true)

        newArrayList = arrayListOf<Messages>()
        getUserdata()
    }

    private fun getUserdata() {
        for(i in imageId.indices){

            val pesan = Messages(imageId[i],sender[i])
            newArrayList.add(pesan)
        }

        newRecyclerView.adapter = Adapter(newArrayList)
    }
}