package learn.idn.message

data class Messages(var titleImage : Int, var heading : String)
